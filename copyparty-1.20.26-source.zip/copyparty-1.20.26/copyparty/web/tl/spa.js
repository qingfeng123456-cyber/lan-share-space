
// Las líneas que terminan con //m son traducciones automáticas no verificadas

Ls.spa = {
	"tt": "Español",

	"cols": {
		"c": "acciones",
		"dur": "duración",
		"q": "calidad / bitrate",
		"Ac": "códec de audio",
		"Vc": "códec de vídeo",
		"Fmt": "formato / contenedor",
		"Ahash": "checksum de audio",
		"Vhash": "checksum de vídeo",
		"Res": "resolución",
		"T": "tipo de archivo",
		"aq": "calidad de audio / bitrate",
		"vq": "calidad de vídeo / bitrate",
		"pixfmt": "submuestreo / estructura de píxel",
		"resw": "resolución horizontal",
		"resh": "resolución vertical",
		"chs": "canales de audio",
		"hz": "frecuencia de muestreo",
	},

	"hks": [
		[
			"varios",
			["ESC", "cerrar varias cosas"],

			"gestor de archivos",
			["G", "alternar vista de lista / cuadrícula"],
			["T", "alternar miniaturas / iconos"],
			["⇧ A/D", "tamaño de miniatura"],
			["ctrl-K", "eliminar seleccionados"],
			["ctrl-X", "cortar selección al portapapeles"],
			["ctrl-C", "copiar selección al portapapeles"],
			["ctrl-V", "pegar (mover/copiar) aquí"],
			["Y", "descargar seleccionados"],
			["F2", "renombrar seleccionados"],
			["F4", "actualizar"], //m

			"selección en lista de archivos",
			["space", "alternar selección de archivo"],
			["↑/↓", "mover cursor de selección"],
			["ctrl ↑/↓", "mover cursor y vista"],
			["⇧ ↑/↓", "seleccionar anterior/siguiente archivo"],
			["ctrl-A", "seleccionar todos los archivos / carpetas"]
		], [
			"navegación",
			["B", "alternar breadcrumbs / panel de navegación"],
			["I/K", "anterior/siguiente carpeta"],
			["M", "carpeta de nivel superior (o contraer actual)"],
			["V", "alternar carpetas / archivos en panel de navegación"],
			["A/D", "tamaño del panel de navegación"]
		], [
			"reproductor de audio",
			["J/L", "anterior/siguiente canción"],
			["U/O", "saltar 10s atrás/adelante"],
			["0..9", "saltar a 0%..90%"],
			["P", "reproducir/pausar (también inicia)"],
			["S", "seleccionar canción en reproducción"],
			["Y", "descargar canción"]
		], [
			"visor de imágenes",
			["J/L, ←/→", "anterior/siguiente imagen"],
			["Home/End", "primera/última imagen"],
			["F", "pantalla completa"],
			["R", "rotar en sentido horario"],
			["⇧ R", "rotar en sentido antihorario"],
			["S", "seleccionar imagen"],
			["Y", "descargar imagen"]
		], [
			"reproductor de vídeo",
			["U/O", "saltar 10s atrás/adelante"],
			["P/K/Space", "reproducir/pausar"],
			["C", "continuar con el siguiente"],
			["V", "bucle"],
			["M", "silenciar"],
			["[ y ]", "establecer intervalo de bucle"]
		], [
			"visor de texto",
			["I/K", "anterior/siguiente archivo"],
			["M", "cerrar archivo"],
			["E", "editar archivo"],
			["S", "seleccionar archivo (para cortar/copiar/renombrar)"],
			["Y", "descargar archivo de texto"], //m
			["⇧ J", "embellecer json"], //m
		]
	],

	"m_ok": "Aceptar",
	"m_ng": "Cancelar",

	"enable": "Activar",
	"danger": "PELIGRO",
	"clipped": "copiado al portapapeles",

	"ht_s1": "segundo",
	"ht_s2": "segundos",
	"ht_m1": "minuto",
	"ht_m2": "minutos",
	"ht_h1": "hora",
	"ht_h2": "horas",
	"ht_d1": "día",
	"ht_d2": "días",
	"ht_and": " y ",

	"goh": "panel de control",
	"gop": 'hermano anterior">anterior',
	"gou": 'carpeta de nivel superior">subir',
	"gon": 'siguiente carpeta">siguiente',
	"logout": "Cerrar sesión ",
	"login": "Iniciar sesión", //m
	"access": " acceso",
	"ot_close": "cerrar submenú",
	"ot_search": "`buscar archivos por atributos, ruta / nombre, etiquetas de música, o cualquier combinación$N$N`foo bar` = debe contener «foo» y «bar»,$N`foo -bar` = debe contener «foo» pero no «bar»,$N`^yana .opus$` = empieza con «yana» y es un archivo «opus»$N`&quot;try unite&quot;` = contiene exactamente «try unite»$N$Nel formato de fecha es iso-8601, como$N`2009-12-31` o `2020-09-12 23:30:00`",
	"ot_unpost": "dessubir: elimina tus subidas recientes, o aborta las inacabadas",
	"ot_bup": "bup: uploader básico, soporta hasta netscape 4.0",
	"ot_mkdir": "mkdir: crear un nuevo directorio",
	"ot_md": "new-file: crear un nuevo archivo de texto", //m
	"ot_msg": "msg: enviar un mensaje al registro del servidor",
	"ot_mp": "opciones del reproductor multimedia",
	"ot_cfg": "opciones de configuración",
	"ot_u2i": "up2k: subir archivos (si tienes acceso de escritura) o cambiar a modo de búsqueda para ver si existen en el servidor$N$Nlas subidas se pueden reanudar, usan múltiples hilos y conservan la fecha de los archivos, pero consume más CPU que [🎈]&nbsp; (el uploader básico)<br /><br />¡Durante las subidas, este icono se convierte en un indicador de progreso!",
	"ot_u2w": "up2k: subir archivos con soporte para reanudación (cierra tu navegador y arrastra los mismos archivos más tarde)$N$NMultihilo y conserva las fechas de los archivos, pero usa más CPU que [🎈]&nbsp; (el uploader básico)<br /><br />¡Durante las subidas, este icono se convierte en un indicador de progreso!",
	"ot_noie": "Por favor, usa Chrome / Firefox / Edge",

	"ab_mkdir": "crear directorio",
	"ab_mkdoc": "nuevo archivo de texto", //m
	"ab_msg": "enviar msg al registro del servidor",

	"ay_path": "saltar a carpetas",
	"ay_files": "saltar a archivos",

	"wt_ren": "renombrar elementos seleccionados$NAtajo: F2",
	"wt_del": "eliminar elementos seleccionados$NAtajo: ctrl-K",
	"wt_cut": "cortar elementos seleccionados &lt;small&gt;(luego pegar en otro lugar)&lt;/small&gt;$NAtajo: ctrl-X",
	"wt_cpy": "copiar elementos seleccionados al portapapeles$N(para pegarlos en otro lugar)$NAtajo: ctrl-C",
	"wt_pst": "pegar una selección previamente cortada / copiada$NAtajo: ctrl-V",
	"wt_selall": "seleccionar todos los archivos$NAtajo: ctrl-A (con un archivo con foco)",
	"wt_selinv": "invertir selección",
	"wt_zip1": "descargar esta carpeta como un archivo comprimido",
	"wt_selzip": "descargar selección como archivo comprimido",
	"wt_seldl": "descargar selección como archivos separados$NAtajo: Y",
	"wt_npirc": "copiar información de pista en formato IRC",
	"wt_nptxt": "copiar información de pista en texto plano",
	"wt_m3ua": "añadir a lista m3u (haz clic en <code>📻copiar</code> después)",
	"wt_m3uc": "copiar lista m3u al portapapeles",
	"wt_grid": "alternar vista de cuadrícula / lista$NAtajo: G",
	"wt_prev": "pista anterior$NAtajo: J",
	"wt_play": "reproducir / pausar$NAtajo: P",
	"wt_next": "siguiente pista$NAtajo: L",

	"ul_par": "subidas paralelas:",
	"ut_rand": "aleatorizar nombres de archivo",
	"ut_u2ts": 'copiar la fecha de última modificación$Nde tu sistema de archivos al servidor">📅',
	"ut_ow": "sobrescribir archivos existentes en el servidor?$N🛡️: nunca (generará un nuevo nombre de archivo en su lugar)$N🕒: sobrescribir si el archivo del servidor es más antiguo que el tuyo$N♻️: siempre sobrescribir si los archivos son diferentes$N⏭️: omitir incondicionalmente todos los archivos existentes", //m
	"ut_mt": "continuar generando hashes de otros archivos mientras se sube$N$Nquizás desactivar si tu CPU o HDD es un cuello de botella",
	"ut_ask": 'pedir confirmación antes de iniciar la subida">💭',
	"ut_pot": "mejorar la velocidad de subida en dispositivos lentos$Nsimplificando la interfaz de usuario",
	"ut_srch": "no subir, en su lugar comprobar si los archivos ya $N existen en el servidor (escaneará todas las carpetas que puedas leer)",
	"ut_par": "pausar subidas poniéndolo a 0$N$Naumentar si tu conexión es lenta / de alta latencia$N$Nmantener en 1 en LAN o si el HDD del servidor es un cuello de botella",
	"ul_btn": "arrastra archivos / carpetas<br>aquí (o haz clic)",
	"ul_btnu": "S U B I R",
	"ul_btns": "B U S C A R",

	"ul_hash": "hash",
	"ul_send": "envio",
	"ul_done": "hecho",
	"ul_idle1": "aún no hay subidas en cola",
	"ut_etah": "velocidad media de &lt;em&gt;hashing&lt;/em&gt;, y tiempo estimado para finalizar",
	"ut_etau": "velocidad media de &lt;em&gt;subida&lt;/em&gt; y tiempo estimado para finalizar",
	"ut_etat": "velocidad media &lt;em&gt;total&lt;/em&gt; y tiempo estimado para finalizar",

	"uct_ok": "completado con éxito",
	"uct_ng": "fallido: error / rechazado / no encontrado",
	"uct_done": "éxitos y fallos combinados",
	"uct_bz": "generando hash o subiendo",
	"uct_q": "inactivo, pendiente",

	"utl_name": "nombre de archivo",
	"utl_ulist": "lista",
	"utl_ucopy": "copiar",
	"utl_links": "enlaces",
	"utl_stat": "estado",
	"utl_prog": "progreso",

	"utl_404": "404",
	"utl_err": "ERROR",
	"utl_oserr": "Error-SO",
	"utl_found": "encontrado",
	"utl_defer": "posponer",
	"utl_yolo": "YOLO",
	"utl_done": "hecho",

	"ul_flagblk": "los archivos se añadieron a la cola</b><br>sin embargo, hay un up2k ocupado en otra pestaña del navegador,<br>esperando a que termine primero",
	"ul_btnlk": "la configuración del servidor ha bloqueado esta opción en este estado",

	"udt_up": "Subir",
	"udt_srch": "Buscar",
	"udt_drop": "suéltalo aquí",

	"u_nav_m": "<h6>vale, ¿qué tienes?</h6><code>Intro</code> = Archivos (uno o más)\n<code>ESC</code> = Una carpeta (incluyendo subcarpetas)",
	"u_nav_b": "<a href=\"#\" id=\"modal-ok\">Archivos</a><a href=\"#\" id=\"modal-ng\">Una carpeta</a>",

	"cl_opts": "opciones",
	"cl_hfsz": "tamaño del archivo", //m
	"cl_themes": "tema",
	"cl_langs": "idioma",
	"cl_ziptype": "descarga de carpeta",
	"cl_uopts": "opciones up2k",
	"cl_favico": "favicon",
	"cl_bigdir": "directorios grandes",
	"cl_hsort": "#ordenar",
	"cl_keytype": "notación musical",
	"cl_hiddenc": "columnas ocultas",
	"cl_hidec": "ocultar",
	"cl_reset": "restablecer",
	"cl_hpick": "toca en las cabeceras de columna para ocultarlas en la tabla de abajo",
	"cl_hcancel": "ocultación de columna cancelada",
	"cl_rcm": "menú contextual", //m
	"cl_gauto": "auto田", //m

	"ct_grid": '田 cuadrícula',
	"ct_ttips": '◔ ◡ ◔">ℹ️ tooltips',
	"ct_thumb": 'en vista de cuadrícula, alternar iconos o miniaturas$NAtajo: T">🖼️ miniaturas',
	"ct_csel": 'usa CTRL y SHIFT para seleccionar archivos en la vista de cuadrícula">sel',
	"ct_dsel": 'usa la selección por arrastre en la vista de cuadrícula">arrastrar', //m
	"ct_dl": 'forzar descarga (no mostrar en línea) al hacer clic en un archivo">dl', //m
	"ct_ihop": 'al cerrar el visor de imágenes, desplazarse hasta el último archivo visto">g⮯',
	"ct_dots": 'mostrar archivos ocultos (si el servidor lo permite)">archivos ocultos',
	"ct_qdel": 'al eliminar archivos, pedir confirmación solo una vez">elim. rápida',
	"ct_dir1st": 'ordenar carpetas antes que archivos">📁 primero',
	"ct_nsort": 'orden natural (para nombres de archivo con dígitos iniciales)">ord. natural',
	"ct_utc": 'use UTC para todas las horas">UTC', //m
	"ct_readme": 'mostrar README.md en los listados de carpetas">📜 léeme',
	"ct_idxh": 'mostrar index.html en lugar del listado de carpetas">htm',
	"ct_sbars": 'mostrar barra lateral">⟊',

	"cut_umod": 'si un archivo ya existe en el servidor, actualiza la fecha de última modificación del servidor para que coincida con tu archivo local (requiere permisos de escritura+eliminación)">re📅',

	"cut_turbo": 'el botón yolo, probablemente NO quieras activarlo:$N$Núsalo si estabas subiendo una gran cantidad de archivos y tuviste que reiniciar por alguna razón, y quieres continuar la subida lo antes posible$N$Nesto reemplaza la comprobación de hash por un simple <em>&quot;¿tiene este el mismo tamaño de archivo en el servidor?&quot;</em> así que si el contenido del archivo es diferente, NO se subirá$N$Ndeberías desactivar esto cuando la subida termine, y luego &quot;subir&quot; los mismos archivos de nuevo para que el cliente los verifique">turbo',

	"cut_datechk": 'no tiene efecto a menos que el botón turbo esté activado$N$Nreduce el factor yolo en una pequeña cantidad; comprueba si las fechas de los archivos en el servidor coinciden con las tuyas$N$N<em>teóricamente</em> debería detectar la mayoría de las subidas inacabadas / corruptas, pero no es un sustituto de hacer una pasada de verificación con el turbo desactivado después">verif. fecha',

	"cut_u2sz": "tamaño (en MiB) de cada trozo de subida; los valores grandes vuelan mejor a través del atlántico. Prueba valores bajos en conexiones muy poco fiables",

	"cut_flag": "asegura que solo una pestaña esté subiendo a la vez $N -- otras pestañas también deben tener esto activado $N -- solo afecta a pestañas en el mismo dominio",

	"cut_az": "subir archivos en orden alfabético, en lugar de los más pequeños primero$N$Nel orden alfabético puede facilitar la detección visual de si algo salió mal en el servidor, pero hace la subida ligeramente más lenta en fibra / LAN",

	"cut_nag": "notificación del SO cuando la subida se complete$N(solo si el navegador o la pestaña no están activos)",
	"cut_sfx": "alerta sonora cuando la subida se complete$N(solo si el navegador o la pestaña no están activos)",

	"cut_mt": 'usar multithreading para acelerar el hashing de archivos$N$Nesto usa web-workers y requiere$Nmás RAM (hasta 512 MiB extra)$N$Nhace https un 30% más rápido, http 4.5x más rápido">mt',

	"cut_wasm": 'usar wasm en lugar del hasher incorporado del navegador; mejora la velocidad en navegadores basados en chrome pero aumenta la carga de la CPU, y muchas versiones antiguas de chrome tienen errores que hacen que el navegador consuma toda la RAM y se bloquee si esto está activado">wasm',

	"cft_text": "texto del favicon (dejar en blanco y refrescar para desactivar)",
	"cft_fg": "color de primer plano",
	"cft_bg": "color de fondo",

	"cdt_lim": "número máximo de archivos a mostrar en una carpeta",
	"cdt_ask": "al llegar al final,$Nen lugar de cargar más archivos,$Npreguntar qué hacer",
	"cdt_hsort": "`cuántas reglas de ordenación (`,sorthref`) incluir en las URLs de medios. Ponerlo a 0 también ignorará las reglas de ordenación incluidas en los enlaces de medios al hacer clic en ellos",
	"cdt_ren": "habilitar menú contextual personalizado, el menú normal sigue siendo accesible con shift + clic derecho\">activar", //m
	"cdt_rdb": "mostrar el menú normal de clic derecho cuando el personalizado ya está abierto y se vuelve a hacer clic\">x2", //m

	"tt_entree": "mostrar panel de navegación (barra lateral con árbol de directorios)$NAtajo: B",
	"tt_detree": "mostrar breadcrumbs$NAtajo: B",
	"tt_visdir": "desplazarse a la carpeta seleccionada",
	"tt_ftree": "alternar árbol de carpetas / archivos de texto$NAtajo: V",
	"tt_pdock": "mostrar carpetas de niveles superiores en un panel acoplado en la parte superior",
	"tt_dynt": "crecimiento automático a medida que el árbol se expande",
	"tt_wrap": "ajuste de línea",
	"tt_hover": "revelar líneas que se desbordan al pasar el ratón$N( rompe el desplazamiento a menos que el $N&nbsp; cursor esté en el margen izquierdo )",
	"tt_gauto": "mostrar como cuadrícula o lista según el contenido de la carpeta", //m
	"tt_gathr": "usar cuadrícula si este porcentaje de archivos son imágenes/videos", //m

	"ml_pmode": "al final de la carpeta...",
	"ml_btns": "acciones",
	"ml_tcode": "transcodificar",
	"ml_tcode2": "transcodificar a",
	"ml_tint": "tinte",
	"ml_eq": "ecualizador de audio",
	"ml_drc": "compresor de rango dinámico",
	"ml_ss": "saltar silencios", //m

	"mt_loop": 'poner en bucle/repetir una canción">🔁',
	"mt_one": 'parar después de una canción">1️⃣',
	"mt_shuf": 'reproducir aleatoriamente las canciones en cada carpeta">🔀',
	"mt_aplay": 'reproducir automaticamente si hay un ID de canción en el enlace en el que hiciste clic para acceder al servidor$N$Ndesactivar esto también evitará que la URL de la página se actualice con IDs de canción al reproducir música, para prevenir la reproducción automática si se pierden estos ajustes pero la URL permanece">a▶',
	"mt_preload": 'empezar a cargar la siguiente canción cerca del final para una reproducción sin pausas">precarga',
	"mt_prescan": 'ir a la siguiente carpeta antes de que la última canción$Ntermine, manteniendo contento al navegador$Npara que no detenga la reproducción">nav',
	"mt_fullpre": 'intentar precargar la canción entera;$N✅ activar en conexiones <b>inestables</b>,$N❌ <b>desactivar</b> probablemente en conexiones lentas">completa',
	"mt_fau": 'en teléfonos, evitar que la música se detenga si la siguiente canción no se precarga lo suficientemente rápido (puede causar fallos en la visualización de etiquetas)">☕️',
	"mt_waves": 'barra de búsqueda con forma de onda:$Nmostrar la amplitud del audio en la barra de progreso">~s',
	"mt_npclip": 'mostrar botones para copiar al portapapeles la canción actual">/np',
	"mt_m3u_c": 'mostrar botones para copiar al portapapeles las$Ncanciones seleccionadas como entradas de lista m3u8">📻',
	"mt_octl": 'integración con SO (teclas multimedia / OSD)">ctl-so',
	"mt_oseek": 'permitir buscar a través de la integración con el SO$N$Nnota: en algunos dispositivos (iPhones),$Nesto reemplaza el botón de siguiente canción">búsqueda',
	"mt_oscv": 'mostrar carátula del álbum en OSD">arte',
	"mt_follow": 'mantener la pista en reproducción visible en pantalla">🎯',
	"mt_compact": 'controles compactos">⟎',
	"mt_uncache": 'limpiar caché &nbsp;(prueba esto si tu navegador guardó en caché$Nuna copia rota de una canción que se niega a reproducir)">limpiar caché',
	"mt_mloop": 'repetir la carpeta actual">🔁 bucle',
	"mt_mnext": 'cargar la siguiente carpeta y continuar">📂 sig',
	"mt_mstop": 'detener reproducción">⏸ parar',
	"mt_cflac": 'convertir flac / wav a {0}">flac',
	"mt_caac": 'convertir aac / m4a a {0}">aac',
	"mt_coth": 'convertir todos los demás (no mp3) a {0}">oth',
	"mt_c2opus": 'la mejor opción para ordenadores, portátiles, android">opus',
	"mt_c2owa": 'opus-weba, para iOS 17.5 y superior">owa',
	"mt_c2caf": 'opus-caf, para iOS 11 a 17">caf',
	"mt_c2mp3": 'usar en dispositivos muy antiguos">mp3',
	"mt_c2flac": "la mejor calidad de sonido,$Npero descargas muy grandes\">flac", //m
	"mt_c2wav": "reproducción sin comprimir (aún más grande)\">wav", //m
	"mt_c2ok": "bien, buena elección",
	"mt_c2nd": "ese no es el formato de salida recomendado para tu dispositivo, pero está bien",
	"mt_c2ng": "tu dispositivo no parece soportar este formato de salida, pero intentémoslo de todas formas",
	"mt_xowa": "hay errores en iOS que impiden la reproducción en segundo plano con este formato; por favor, usa caf o mp3 en su lugar",
	"mt_tint": "nivel de fondo (0-100) en la barra de búsqueda$Npara hacer el buffering menos molesto",
	"mt_eq": "`activa el ecualizador y el control de ganancia;$N$Nganancia `0` = volumen estándar 100% (sin modificar)$N$Nancho `1 &nbsp;` = estéreo estándar (sin modificar)$Nancho `0.5` = 50% de crossfeed izq-der$Nancho `0 &nbsp;` = mono$N$Nganancia `-0.8` y ancho `10` = eliminación de voz :^)$N$Nactivar el ecualizador hace que los álbumes sin pausas sean completamente sin pausas, así que déjalo activado con todos los valores a cero (excepto ancho = 1) si eso te importa",
	"mt_drc": "activa el compresor de rango dinámico (aplanador de volumen / brickwaller); también activará el EQ para equilibrar el espagueti, así que pon todos los campos de EQ excepto 'ancho' a 0 si no lo quieres$N$Nbaja el volumen del audio por encima de THRESHOLD dB; por cada RATIO dB pasado THRESHOLD hay 1 dB de salida, así que los valores por defecto de umbral -24 y ratio 12 significan que nunca debería sonar más fuerte de -22 dB y es seguro aumentar la ganancia del ecualizador a 0.8, o incluso 1.8 con ATK 0 y un RLS enorme como 90 (solo funciona en firefox; RLS es máx. 1 en otros navegadores)$N$N(ver wikipedia, lo explican mucho mejor)",
	"mt_ss": "`activa salto de silencio; multiplica la velocidad por `av` cerca del inicio/fin cuando el volumen está bajo `vol` y la posición está en los primeros `ini`% o últimos `fin`%", //m
	"mt_ssvt": "umbral de volumen (0-255)\">vol", //m
	"mt_ssts": "umbral activo (% pista, inicio)\">ini", //m
	"mt_sste": "umbral activo (% pista, fin)\">fin", //m
	"mt_sssm": "multiplicador de velocidad de reproducción\">av", //m

	"mb_play": "reproducir",
	"mm_hashplay": "¿reproducir este archivo de audio?",
	"mm_m3u": "pulsa <code>Intro/Aceptar</code> para Reproducir\npulsa <code>ESC/Cancelar</code> para Editar",
	"mp_breq": "se necesita firefox 82+ o chrome 73+ o iOS 15+",
	"mm_bload": "cargando...",
	"mm_bconv": "convirtiendo a {0}, por favor espera...",
	"mm_opusen": "tu navegador no puede reproducir archivos aac / m4a;\nse ha activado la transcodificación a opus",
	"mm_playerr": "fallo de reproducción: ",
	"mm_eabrt": "El intento de reproducción fue cancelado",
	"mm_enet": "Tu conexión a internet es inestable",
	"mm_edec": "¿Este archivo está supuestamente corrupto?",
	"mm_esupp": "Tu navegador no entiende este formato de audio",
	"mm_eunk": "Error desconocido",
	"mm_e404": "No se pudo reproducir el audio; error 404: Archivo no encontrado.",
	"mm_e403": "No se pudo reproducir el audio; error 403: Acceso denegado.\n\nIntenta pulsar F5 para recargar, quizás se cerró tu sesión",
	"mm_e415": "No se pudo reproducir el audio; error 415: Falló la conversión del archivo; revisa los registros del servidor.", //m
	"mm_e500": "No se pudo reproducir el audio; error 500: Revisa los registros del servidor.",
	"mm_e5xx": "No se pudo reproducir el audio; error del servidor ",
	"mm_nof": "no se encuentran más archivos de audio cerca",
	"mm_prescan": "Buscando música para reproducir a continuación...",
	"mm_scank": "Encontrada la siguiente canción:",
	"mm_uncache": "caché limpiada; todas las canciones se volverán a descargar en la próxima reproducción",
	"mm_hnf": "esa canción ya no existe",

	"im_hnf": "esa imagen ya no existe",

	"f_empty": "esta carpeta está vacía",
	"f_chide": "esto ocultará la columna «{0}»\n\npuedes volver a mostrar las columnas en la pestaña de configuración",
	"f_bigtxt": "este archivo pesa {0} MiB -- ¿realmente verlo como texto?",
	"f_bigtxt2": "¿ver solo el final del archivo en su lugar? esto también activará el seguimiento, mostrando las líneas de texto recién añadidas en tiempo real",
	"fbd_more": '<div id="blazy">mostrando <code>{0}</code> de <code>{1}</code> archivos; <a href="#" id="bd_more">mostrar {2}</a> o <a href="#" id="bd_all">mostrar todos</a></div>',
	"fbd_all": '<div id="blazy">mostrando <code>{0}</code> de <code>{1}</code> archivos; <a href="#" id="bd_all">mostrar todos</a></div>',
	"f_anota": "solo {0} de los {1} elementos fueron seleccionados;\npara seleccionar la carpeta completa, primero desplázate hasta el final",

	"f_dls": "los enlaces a archivos en la carpeta actual se han\nconvertido en enlaces de descarga",
	"f_dl_nd": 'omitiendo carpeta (use la descarga zip/tar en su lugar):\n', //m

	"f_partial": "Para descargar de forma segura un archivo que se está subiendo actualmente, por favor haz clic en el archivo con el mismo nombre, pero sin la extensión <code>.PARTIAL</code>. Por favor, pulsa CANCELAR o Escape para hacer esto.\n\nPulsar ACEPTAR o Intro ignorará esta advertencia y continuará descargando el archivo temporal <code>.PARTIAL</code>, lo que casi con toda seguridad te dará datos corruptos.",

	"ft_paste": "pegar {0} elementos$NAtajo: ctrl-V",
	"fr_eperm": "no se puede renombrar:\nno tienes permiso de “mover” en esta carpeta",
	"fd_eperm": "no se puede eliminar:\nno tienes permiso de “eliminar” en esta carpeta",
	"fc_eperm": "no se puede cortar:\nno tienes permiso de “mover” en esta carpeta",
	"fp_eperm": "no se puede pegar:\nno tienes permiso de “escribir” en esta carpeta",
	"fr_emore": "selecciona al menos un elemento para renombrar",
	"fd_emore": "selecciona al menos un elemento para eliminar",
	"fc_emore": "selecciona al menos un elemento para cortar",
	"fcp_emore": "selecciona al menos un elemento para copiar al portapapeles",

	"fs_sc": "compartir la carpeta en la que estás",
	"fs_ss": "compartir los archivos seleccionados",
	"fs_just1d": "no puedes seleccionar más de una carpeta,\no mezclar archivos y carpetas en una selección",
	"fs_abrt": "❌ abortar",
	"fs_rand": "🎲 nombre aleatorio",
	"fs_go": "✅ crear enlace",
	"fs_name": "nombre",
	"fs_src": "origen",
	"fs_pwd": "contraseña",
	"fs_exp": "caducidad",
	"fs_tmin": "minutos",
	"fs_thrs": "horas",
	"fs_tdays": "días",
	"fs_never": "eterno",
	"fs_pname": "nombre opcional del enlace; será aleatorio si se deja en blanco",
	"fs_tsrc": "el archivo o carpeta a compartir",
	"fs_ppwd": "contraseña opcional",
	"fs_w8": "creando enlace...",
	"fs_ok": "pulsa <code>Intro/Aceptar</code> para Copiar al Portapapeles\npulsa <code>ESC/Cancelar</code> para Cerrar",

	"frt_dec": "puede arreglar algunos casos de nombres de archivo rotos\">url-decode",
	"frt_rst": "restaurar los nombres de archivo modificados a los originales\">↺ restablecer",
	"frt_abrt": "abortar y cerrar esta ventana\">❌ cancelar",
	"frb_apply": "APLICAR RENOMBRADO",
	"fr_adv": "renombrado por lotes / metadatos / patrones\">avanzado",
	"fr_case": "regex sensible a mayúsculas\">mayús",
	"fr_win": "nombres seguros para windows; reemplaza <code>&lt;&gt;:&quot;\\|?*</code> con caracteres japoneses de ancho completo\">win",
	"fr_slash": "reemplaza <code>/</code> con un carácter que no cree nuevas carpetas\">sin /",
	"fr_re": "`patrón de búsqueda regex para aplicar a los nombres de archivo originales; los grupos de captura se pueden referenciar en el campo de formato de abajo como `(1)` y `(2)` y así sucesivamente",
	"fr_fmt": "`inspirado en foobar2000:$N`(title)` se reemplaza por el título de la canción,$N`[(artist) - ](title)` omite la parte [entre corchetes] si el artista está en blanco$N`$lpad((tn),2,0)` rellena el número de pista a 2 dígitos",
	"fr_pdel": "eliminar",
	"fr_pnew": "guardar como",
	"fr_pname": "proporciona un nombre para tu nuevo preajuste",
	"fr_aborted": "abortado",
	"fr_lold": "nombre antiguo",
	"fr_lnew": "nombre nuevo",
	"fr_tags": "etiquetas para los archivos seleccionados (solo lectura, como referencia):",
	"fr_busy": "renombrando {0} elementos...\n\n{1}",
	"fr_efail": "fallo al renombrar:\n",
	"fr_nchg": "{0} de los nuevos nombres fueron alterados debido a <code>win</code> y/o <code>sin /</code>\n\n¿Aceptar para continuar con estos nuevos nombres alterados?",

	"fd_ok": "eliminación correcta",
	"fd_err": "fallo al eliminar:\n",
	"fd_none": "no se eliminó nada; quizás bloqueado por la configuración del servidor (xbd)?",
	"fd_busy": "eliminando {0} elementos...\n\n{1}",
	"fd_warn1": "¿ELIMINAR estos {0} elementos?",
	"fd_warn2": "<b>¡Última oportunidad!</b> No se puede deshacer. ¿Eliminar?",

	"fc_ok": "cortados {0} elementos",
	"fc_warn": "cortados {0} elementos\n\npero: solo <b>esta</b> pestaña del navegador puede pegarlos\n(dado que la selección es absolutamente masiva)",

	"fcc_ok": "copiados {0} elementos al portapapeles",
	"fcc_warn": "copiados {0} elementos al portapapeles\n\npero: solo <b>esta</b> pestaña del navegador puede pegarlos\n(dado que la selección es absolutamente masiva)",

	"fp_apply": "usar estos nombres",
	"fp_skip": "omitir conflictos", //m
	"fp_ecut": "primero corta o copia algunos archivos / carpetas para pegar / mover\n\nnota: puedes cortar / pegar entre diferentes pestañas del navegador",
	"fp_ename": "{0} elementos no se pueden mover aquí porque los nombres ya existen. Dales nuevos nombres abajo para continuar, o deja el nombre en blanco (\"omitir conflictos\") para omitirlos:", //m
	"fcp_ename": "{0} elementos no se pueden copiar aquí porque los nombres ya existen. Dales nuevos nombres abajo para continuar, o deja el nombre en blanco (\"omitir conflictos\") para omitirlos:", //m
	"fp_emore": "todavía quedan algunas colisiones de nombres por resolver",
	"fp_ok": "movimiento correcto",
	"fcp_ok": "copia correcta",
	"fp_busy": "moviendo {0} elementos...\n\n{1}",
	"fcp_busy": "copiando {0} elementos...\n\n{1}",
	"fp_abrt": "cancelando...", //m
	"fp_err": "fallo al mover:\n",
	"fcp_err": "fallo al copiar:\n",
	"fp_confirm": "¿mover estos {0} elementos aquí?",
	"fcp_confirm": "¿copiar estos {0} elementos aquí?",
	"fp_etab": "fallo al leer el portapapeles de otra pestaña del navegador",
	"fp_name": "subiendo un archivo desde tu dispositivo. Dale un nombre:",
	"fp_both_m": "<h6>elige qué pegar</h6><code>Intro</code> = Mover {0} archivos desde «{1}»\n<code>ESC</code> = Subir {2} archivos desde tu dispositivo",
	"fcp_both_m": "<h6>elige qué pegar</h6><code>Intro</code> = Copiar {0} archivos desde «{1}»\n<code>ESC</code> = Subir {2} archivos desde tu dispositivo",
	"fp_both_b": "<a href=\"#\" id=\"modal-ok\">Mover</a><a href=\"#\" id=\"modal-ng\">Subir</a>",
	"fcp_both_b": "<a href=\"#\" id=\"modal-ok\">Copiar</a><a href=\"#\" id=\"modal-ng\">Subir</a>",

	"mk_noname": "escribe un nombre en el campo de texto de la izquierda antes de hacer eso :p",
	"nmd_i1": "también puedes añadir la extensión que quieras, por ejemplo <code>.md</code>", //m
	"nmd_i2": "solo puedes crear archivos <code>.{0}</code> porque no tienes permiso para borrar", //m

	"tv_load": "Cargando documento de texto:\n\n{0}\n\n{1}% ({2} de {3} MiB cargados)",
	"tv_xe1": "no se pudo cargar el archivo de texto:\n\nerror ",
	"tv_xe2": "404, archivo no encontrado",
	"tv_lst": "lista de archivos de texto en",
	"tvt_close": "volver a la vista de carpetas$NAtajo: M (o Esc)\">❌ cerrar",
	"tvt_dl": "descargar este archivo$NAtajo: Y\">💾 descargar",
	"tvt_prev": "mostrar documento anterior$NAtajo: i\">⬆ ant",
	"tvt_next": "mostrar siguiente documento$NAtajo: K\">⬇ sig",
	"tvt_sel": "seleccionar archivo &nbsp; ( para cortar / copiar / eliminar / ... )$NAtajo: S\">sel",
	"tvt_j": "embellecer json$NAtajo: shift-J\">j", //m
	"tvt_edit": "abrir archivo en editor de texto$NAtajo: E\">✏️ editar",
	"tvt_tail": "monitorizar cambios en el archivo; mostrar nuevas líneas en tiempo real\">📡 seguir",
	"tvt_wrap": "ajuste de línea\">↵",
	"tvt_atail": "bloquear el desplazamiento al final de la página\">⚓",
	"tvt_ctail": "decodificar colores de terminal (códigos de escape ansi)\">🌈",
	"tvt_ntail": "límite de historial (cuántos bytes de texto mantener cargados)",

	"m3u_add1": "canción añadida a la lista m3u",
	"m3u_addn": "{0} canciones añadidas a la lista m3u",
	"m3u_clip": "lista m3u copiada al portapapeles\n\ndebes crear un nuevo archivo de texto llamado algo.m3u y pegar la lista en ese documento; esto lo hará reproducible",

	"gt_vau": "no mostrar vídeos, solo reproducir el audio\">🎧",
	"gt_msel": "activar selección de archivos; ctrl-clic en un archivo para anular$N$N&lt;em&gt;cuando está activo: doble clic en un archivo / carpeta para abrirlo&lt;/em&gt;$N$NAtajo: S\">multiselección",
	"gt_crop": "recortar miniaturas\">recortar",
	"gt_3x": "miniaturas de alta resolución\">3x",
	"gt_zoom": "zoom",
	"gt_chop": "recortar",
	"gt_sort": "ordenar por",
	"gt_name": "nombre",
	"gt_sz": "tamaño",
	"gt_ts": "fecha",
	"gt_ext": "tipo",
	"gt_c1": "truncar más los nombres de archivo (mostrar menos)",
	"gt_c2": "truncar menos los nombres de archivo (mostrar más)",

	"sm_w8": "buscando...",
	"sm_prev": "los resultados de búsqueda a continuación son de una consulta anterior:\n  ",
	"sl_close": "cerrar resultados de búsqueda",
	"sl_hits": "mostrando {0} resultados",
	"sl_moar": "cargar más",

	"s_sz": "tamaño",
	"s_dt": "fecha",
	"s_rd": "ruta",
	"s_fn": "nombre",
	"s_ta": "etiquetas",
	"s_ua": "subido@",
	"s_ad": "avanzado",
	"s_s1": "MiB mínimo",
	"s_s2": "MiB máximo",
	"s_d1": "mín. iso8601",
	"s_d2": "máx. iso8601",
	"s_u1": "subido después de",
	"s_u2": "y/o antes de",
	"s_r1": "la ruta contiene &nbsp; (separado por espacios)",
	"s_f1": "el nombre contiene &nbsp; (negar con -no)",
	"s_t1": "las etiquetas contienen &nbsp; (^=inicio, fin=$)",
	"s_a1": "propiedades de metadatos específicas",

	"md_eshow": "no se puede renderizar ",
	"md_off": "[📜<em>léeme</em>] desactivado en [⚙️] -- documento oculto",

	"badreply": "Fallo al procesar la respuesta del servidor",

	"xhr403": "403: Acceso denegado\n\nintenta pulsar F5, quizás se cerró tu sesión",
	"xhr0": "desconocido (probablemente se perdió la conexión con el servidor, o el servidor está desconectado)",
	"cf_ok": "perdón por eso -- la protección DD" + wah + "oS se activó\n\nlas cosas deberían reanudarse en unos 30 segundos\n\nsi no pasa nada, pulsa F5 para recargar la página",
	"tl_xe1": "no se pudieron listar las subcarpetas:\n\nerror ",
	"tl_xe2": "404: Carpeta no encontrada",
	"fl_xe1": "no se pudieron listar los archivos en la carpeta:\n\nerror ",
	"fl_xe2": "404: Carpeta no encontrada",
	"fd_xe1": "no se pudo crear la subcarpeta:\n\nerror ",
	"fd_xe2": "404: Carpeta de nivel superior no encontrada",
	"fsm_xe1": "no se pudo enviar el mensaje:\n\nerror ",
	"fsm_xe2": "404: Carpeta de nivel superior no encontrada",
	"fu_xe1": "fallo al cargar la lista de deshacer del servidor:\n\nerror ",
	"fu_xe2": "404: ¿Archivo no encontrado?",

	"fz_tar": "archivo gnu-tar sin comprimir (linux / mac)",
	"fz_pax": "tar formato pax sin comprimir (más lento)",
	"fz_targz": "gnu-tar con compresión gzip nivel 3$N$Nesto suele ser muy lento, así que$Nusa tar sin comprimir en su lugar",
	"fz_tarxz": "gnu-tar con compresión xz nivel 1$N$Nesto suele ser muy lento, así que$Nusa tar sin comprimir en su lugar",
	"fz_zip8": "zip con nombres de archivo utf8 (puede dar problemas en windows 7 y anteriores)",
	"fz_zipd": "zip con nombres de archivo cp437 tradicionales, para software muy antiguo",
	"fz_zipc": "cp437 con crc32 calculado tempranamente,$Npara MS-DOS PKZIP v2.04g (octubre 1993)$N(tarda más en procesar antes de que la descarga pueda empezar)",

	"un_m1": "puedes eliminar tus subidas recientes (o abortar las inacabadas) a continuación",
	"un_upd": "actualizar",
	"un_m4": "o compartir los archivos visibles a continuación:",
	"un_ulist": "mostrar",
	"un_ucopy": "copiar",
	"un_flt": "filtro opcional:&nbsp; la URL debe contener",
	"un_fclr": "limpiar filtro",
	"un_derr": "fallo al deshacer-eliminar:\n",
	"un_f5": "algo se rompió, por favor intenta actualizar o pulsa F5",
	"un_uf5": "lo siento pero tienes que refrescar la página (por ejemplo pulsando F5 o CTRL-R) antes de que esta subida pueda ser abortada",
	"un_nou": "<b>aviso:</b> servidor demasiado ocupado para mostrar subidas inacabadas; haz clic en el enlace \"actualizar\" en un momento",
	"un_noc": "<b>aviso:</b> la opción de deshacer subidas completadas no está activada/permitida en la configuración del servidor",
	"un_max": "mostrando los primeros 2000 archivos (usa el filtro)",
	"un_avail": "{0} subidas recientes se pueden eliminar<br />{1} inacabadas se pueden abortar",
	"un_m2": "ordenado por tiempo de subida; más recientes primero:",
	"un_no1": "¡pues no! ninguna subida es suficientemente reciente",
	"un_no2": "¡pues no! ninguna subida que coincida con ese filtro es suficientemente reciente",
	"un_next": "eliminar los siguientes {0} archivos a continuación",
	"un_abrt": "abortar",
	"un_del": "eliminar",
	"un_m3": "cargando tus subidas recientes...",
	"un_busy": "eliminando {0} archivos...",
	"un_clip": "{0} enlaces copiados al portapapeles",

	"u_https1": "deberías",
	"u_https2": "cambiar a https",
	"u_https3": "para un mejor rendimiento",
	"u_ancient": "tu navegador es impresionantemente antiguo -- quizás deberías <a href=\"#\" id=\"u2nah\">usar bup en su lugar</a>",
	"u_nowork": "se necesita firefox 53+ o chrome 57+ o iOS 11+",
	"tail_2old": "se necesita firefox 105+ o chrome 71+ o iOS 14.5+",
	"b2old": 'tu navegador es demasiado antiguo', //m
	"u_nodrop": "tu navegador es demasiado antiguo para subir arrastrando y soltando",
	"u_notdir": "¡eso no es una carpeta!\n\ntu navegador es demasiado antiguo,\npor favor intenta arrastrar y soltar en su lugar",
	"u_uri": "para arrastrar y soltar imágenes desde otras ventanas del navegador,\npor favor suéltalas sobre el gran botón de subida",
	"u_enpot": "cambiar a <a href=\"#\">UI ligera</a> (puede mejorar la velocidad de subida)",
	"u_depot": "cambiar a <a href=\"#\">UI elegante</a> (puede reducir la velocidad de subida)",
	"u_gotpot": "cambiando a la UI ligera para mejorar la velocidad de subida,\n\n¡siéntete libre de no estar de acuerdo y volver a cambiar!",
	"u_pott": "<p>archivos: &nbsp; <b>{0}</b> finalizados, &nbsp; <b>{1}</b> fallidos, &nbsp; <b>{2}</b> ocupados, &nbsp; <b>{3}</b> en cola</p>",
	"u_ever": "este es el uploader básico; up2k necesita al menos<br>chrome 21 // firefox 13 // edge 12 // opera 12 // safari 5.1",
	"u_su2k": "este es el uploader básico; <a href=\"#\" id=\"u2yea\">up2k</a> es mejor",
	"u_uput": "optimizar para velocidad (omitir checksum)",
	"u_ewrite": "no tienes acceso de escritura a esta carpeta",
	"u_eread": "no tienes acceso de lectura a esta carpeta",
	"u_enoi": "la búsqueda de archivos no está activada en la configuración del servidor",
	"u_enoow": "sobrescribir no funcionará aquí; se necesita permiso de eliminación",
	"u_badf": "Estos {0} archivos (de un total de {1}) se omitieron, posiblemente debido a permisos del sistema de archivos:\n\n",
	"u_blankf": "Estos {0} archivos (de un total de {1}) están en blanco / vacíos; ¿subirlos de todos modos?\n\n",
	"u_applef": "Estos {0} archivos (de un total de {1}) probablemente no son deseables;\nPulsa <code>Aceptar/Intro</code> para OMITIR los siguientes archivos,\nPulsa <code>Cancelar/ESC</code> para NO excluir, y SUBIR esos también:\n\n",
	"u_just1": "\nQuizás funcione mejor si seleccionas solo un archivo",
	"u_ff_many": "si usas <b>Linux / MacOS / Android,</b> esta cantidad de archivos <a href=\"https://bugzilla.mozilla.org/show_bug.cgi?id=1790500\" target=\"_blank\"><em>podría</em> bloquear Firefox!</a>\nsi eso ocurre, por favor inténtalo de nuevo (o usa Chrome).",
	"u_up_life": "Esta subida será eliminada del servidor\n{0} después de que se complete",
	"u_asku": "subir estos {0} archivos a <code>{1}</code>",
	"u_unpt": "puedes deshacer / eliminar esta subida usando el 🧯 de arriba a la izquierda",
	"u_bigtab": "a punto de mostrar {0} archivos\n\nesto podría bloquear tu navegador, ¿estás seguro?",
	"u_scan": "Escaneando archivos...",
	"u_dirstuck": "el iterador de directorios se atascó intentando acceder a los siguientes {0} elementos; se omitirán:",
	"u_etadone": "Hecho ({0}, {1} archivos)",
	"u_etaprep": "(preparando para subir)",
	"u_hashdone": "hashing completado",
	"u_hashing": "hash",
	"u_hs": "negociando...",
	"u_started": "los archivos se están subiendo ahora; mira en [🚀]",
	"u_dupdefer": "duplicado; se procesará después de todos los demás archivos",
	"u_actx": "haz clic en este texto para evitar la pérdida de<br />rendimiento al cambiar a otras ventanas/pestañas",
	"u_fixed": "¡OK!&nbsp; Arreglado 👍",
	"u_cuerr": "fallo al subir el trozo {0} de {1};\nprobablemente inofensivo, continuando\n\narchivo: {2}",
	"u_cuerr2": "el servidor rechazó la subida (trozo {0} de {1});\nse reintentará más tarde\n\narchivo: {2}\n\nerror ",
	"u_ehstmp": "se reintentará; mira abajo a la derecha",
	"u_ehsfin": "el servidor rechazó la solicitud para finalizar la subida; reintentando...",
	"u_ehssrch": "el servidor rechazó la solicitud para realizar la búsqueda; reintentando...",
	"u_ehsinit": "el servidor rechazó la solicitud para iniciar la subida; reintentando...",
	"u_eneths": "error de red al realizar la negociación de subida; reintentando...",
	"u_enethd": "error de red al comprobar la existencia del destino; reintentando...",
	"u_cbusy": "esperando a que el servidor vuelva a confiar en nosotros después de un fallo de red...",
	"u_ehsdf": "¡el servidor se quedó sin espacio en disco!\n\nse seguirá reintentando, por si alguien\nlibera suficiente espacio para continuar",
	"u_emtleak1": "parece que tu navegador podría tener una fuga de memoria;\npor favor",
	"u_emtleak2": " <a href=\"{0}\">cambia a https (recomendado)</a> o ",
	"u_emtleak3": " ",
	"u_emtleakc": "prueba lo siguiente:\n<ul><li>pulsa <code>F5</code> para refrescar la página</li><li>luego desactiva el botón &nbsp;<code>mt</code>&nbsp; en los &nbsp;<code>⚙️ ajustes</code></li><li>e intenta esa subida de nuevo</li></ul>Las subidas serán un poco más lentas, pero bueno.\n¡Perdón por las molestias!\n\nPD: chrome v107 <a href=\"https://bugs.chromium.org/p/chromium/issues/detail?id=1354816\" target=\"_blank\">tiene una solución</a> para esto",
	"u_emtleakf": "prueba lo siguiente:\n<ul><li>pulsa <code>F5</code> para refrescar la página</li><li>luego activa <code>🥔</code> (ligera) en la interfaz de subida</li><li>e intenta esa subida de nuevo</li></ul>\nPD: firefox <a href=\"https://bugzilla.mozilla.org/show_bug.cgi?id=1790500\" target=\"_blank\">con suerte tendrá una solución</a> en algún momento",
	"u_s404": "no encontrado en el servidor",
	"u_expl": "explicar",
	"u_maxconn": "la mayoría de los navegadores limitan esto a 6, pero firefox te permite aumentarlo con <code>connections-per-server</code> en <code>about:config</code>",
	"u_tu": '<p class="warn">AVISO: turbo activado, <span>&nbsp;el cliente puede no detectar y reanudar subidas incompletas; ver tooltip del botón turbo</span></p>',
	"u_ts": '<p class="warn">AVISO: turbo activado, <span>&nbsp;los resultados de búsqueda pueden ser incorrectos; ver tooltip del botón turbo</span></p>',
	"u_turbo_c": "turbo está desactivado en la configuración del servidor",
	"u_turbo_g": "desactivando turbo porque no tienes\nprivilegios para listar directorios en este volumen",
	"u_life_cfg": 'autoeliminar después de <input id="lifem" p="60" /> min (o <input id="lifeh" p="3600" /> horas)',
	"u_life_est": 'la subida se eliminará <span id="lifew" tt="hora local">---</span>',
	"u_life_max": "esta carpeta impone una\nvida máxima de {0}",
	"u_unp_ok": "se permite deshacer la subida durante {0}",
	"u_unp_ng": "NO se permitirá deshacer la subida",
	"ue_ro": "tu acceso a esta carpeta es de solo lectura\n\n",
	"ue_nl": "actualmente no has iniciado sesión",
	"ue_la": "actualmente has iniciado sesión como \"{0}\"",
	"ue_sr": "actualmente estás en modo de búsqueda de archivos\n\ncambia a modo de subida haciendo clic en la lupa 🔎 (junto al gran botón BUSCAR), e intenta subir de nuevo\n\nlo siento",
	"ue_ta": "intenta subir de nuevo, ahora debería funcionar",
	"ue_ab": "este archivo ya se está subiendo a otra carpeta, y esa subida debe completarse antes de que el archivo pueda ser subido a otro lugar.\n\nPuedes abortar y olvidar la subida inicial usando el 🧯 de arriba a la izquierda",
	"ur_1uo": "OK: Archivo subido con éxito",
	"ur_auo": "OK: Todos los {0} archivos subidos con éxito",
	"ur_1so": "OK: Archivo encontrado en el servidor",
	"ur_aso": "OK: Todos los {0} archivos encontrados en el servidor",
	"ur_1un": "Subida fallida, lo siento",
	"ur_aun": "Todas las {0} subidas fallaron, lo siento",
	"ur_1sn": "El archivo NO se encontró en el servidor",
	"ur_asn": "Los {0} archivos NO se encontraron en el servidor",
	"ur_um": "Finalizado;\n{0} subidas OK,\n{1} subidas fallidas, lo siento",
	"ur_sm": "Finalizado;\n{0} archivos encontrados en el servidor,\n{1} archivos NO encontrados en el servidor",

	"rc_opn": "abrir", //m
	"rc_ply": "reproducir", //m
	"rc_pla": "reproducir como audio", //m
	"rc_txt": "abrir en el visor de archivos", //m
	"rc_md": "abrir en el editor de texto", //m
	"rc_wopi": "abrir en el editor de office", //m
	"rc_dl": "descargar", //m
	"rc_zip": "descargar como archivo", //m
	"rc_cpl": "copiar enlace", //m
	"rc_del": "eliminar", //m
	"rc_cut": "cortar", //m
	"rc_cpy": "copiar", //m
	"rc_pst": "pegar", //m
	"rc_rnm": "renombrar", //m
	"rc_nfo": "nueva carpeta", //m
	"rc_nfi": "nuevo archivo", //m
	"rc_sal": "seleccionar todo", //m
	"rc_sin": "invertir selección", //m
	"rc_shf": "compartir esta carpeta", //m
	"rc_shs": "compartir selección", //m

	"lang_set": "¿refrescar para que el cambio surta efecto?",

	"splash": {
		"a1": "actualizar",
		"b1": "hola &nbsp; <small>(no has iniciado sesión)</small>",
		"c1": "cerrar sesión",
		"d1": "volcar estado de la pila",
		"d2": "muestra el estado de todos los hilos activos",
		"e1": "recargar configuración",
		"e2": "recargar archivos de configuración (cuentas/volúmenes/indicadores de vol.),$Ny reescanear todos los volúmenes e2ds$N$Nnota: cualquier cambio en la configuración global$Nrequiere un reinicio completo para surtir efecto",
		"f1": "puedes explorar:",
		"g1": "puedes subir a:",
		"cc1": "otras cosas:",
		"h1": "desactivar k304",
		"i1": "activar k304",
		"j1": "activar k304 desconectará tu cliente en cada HTTP 304, lo que puede evitar que algunos proxies con errores se atasquen (dejando de cargar páginas de repente), <em>pero</em> también ralentizará las cosas en general",
		"k1": "restablecer config. de cliente",
		"l1": "inicia sesión para más:",
		"ls3": "iniciar sesión", //m
		"lu4": "nombre de usuario", //m
		"lp4": "contraseña", //m
		"lo3": "cerrar sesión de “{0}” en todas partes", //m
		"lo2": "esto finalizará la sesión en todos los navegadores", //m
		"m1": "bienvenido de nuevo,",
		"n1": "404 no encontrado &nbsp;┐( ´ -`)┌",
		"o1": '¿o quizás no tienes acceso? -- prueba con una contraseña o <a href=\"' + SR + '/?h\">vuelve al inicio</a>',
		"p1": "403 prohibido &nbsp;~┻━┻",
		"q1": 'usa una contraseña o <a href=\"' + SR + '/?h\">vuelve al inicio</a>',
		"r1": "ir al inicio",
		".s1": "reescanear",
		"t1": "acción",
		"u2": "tiempo desde la última escritura en el servidor$N( subida / renombrar / ... )$N$N17d = 17 días$N1h23 = 1 hora 23 minutos$N4m56 = 4 minutos 56 segundos",
		"v1": "conectar",
		"v2": "usar este servidor como un disco duro local",
		"w1": "cambiar a https",
		"x1": "cambiar contraseña",
		"y1": "editar recursos compartidos",
		"z1": "desbloquear este recurso compartido:",
		"ta1": "primero escribe tu nueva contraseña",
		"ta2": "repite para confirmar la nueva contraseña:",
		"ta3": "hay un error; por favor, inténtalo de nuevo",
		"nop": "ERROR: La contraseña no puede estar vacía", //m
		"nou": "ERROR: El nombre de usuario y/o la contraseña no pueden estar vacíos", //m
		"aa1": "archivos entrantes:",
		"ab1": "desactivar no304",
		"ac1": "activar no304",
		"ad1": "activar no304 desactivará todo el almacenamiento en caché; prueba esto si k304 no fue suficiente. ¡Esto desperdiciará una gran cantidad de tráfico de red!",
		"ae1": "descargas activas:",
		"af1": "mostrar subidas recientes",
		"ag1": "mostrar usuarios IdP conocidos",
	}
};
